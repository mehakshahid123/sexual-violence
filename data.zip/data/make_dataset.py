
import os
import pandas as pd

RAW_PATH = os.path.join("data", "raw", "NCRB_Table_3A.3.csv")
PROC_DIR = os.path.join("data", "processed")
EXTERNAL_PATH = os.path.join("data", "external", "state_features.csv")

def clean_columns(cols):
    out = []
    for c in cols:
        c2 = c.lower()
        c2 = c2.replace("(", "").replace(")", "")
        for ch in [" ", "/", ".", "-", ","]:
            c2 = c2.replace(ch, "_")
        while "__" in c2:
            c2 = c2.replace("__", "_")
        c2 = c2.strip("_")
        out.append(c2)
    return out

def load_ncrb():
    df = pd.read_csv(RAW_PATH)
    df.columns = clean_columns(df.columns)
    if "state_ut" in df.columns:
        df = df[~df["state_ut"].str.contains("total", case=False, na=False)].copy()
    for c in df.columns:
        if c in ("sl_no", "state_ut"):
            continue
        df[c] = pd.to_numeric(df[c], errors="coerce")
    rename_map = {"cases_reported_col_3": "cases_reported", "grand_total_col_14": "grand_total"}
    df = df.rename(columns={k: v for k, v in rename_map.items() if k in df.columns})
    return df

def maybe_load_external():
    if os.path.exists(EXTERNAL_PATH):
        ext = pd.read_csv(EXTERNAL_PATH)
        # standardize columns
        ext.columns = clean_columns(ext.columns)
        if "state_ut" not in ext.columns:
            raise ValueError("External features must include a 'State/UT' column (case-insensitive).")
        return ext
    return None

def main():
    os.makedirs(PROC_DIR, exist_ok=True)
    ncrb = load_ncrb()
    ext = maybe_load_external()
    ncrb.to_csv(os.path.join(PROC_DIR, "ncrb_clean.csv"), index=False)
    if ext is not None:
        merged = pd.merge(ncrb, ext, on="state_ut", how="left", suffixes=("", "_ext"))
        merged.to_csv(os.path.join(PROC_DIR, "merged.csv"), index=False)
        print("Saved:", os.path.join(PROC_DIR, "merged.csv"))
    else:
        print("No external features found. Saved cleaned NCRB only.")
        print("Saved:", os.path.join(PROC_DIR, "ncrb_clean.csv"))

if __name__ == "__main__":
    main()
