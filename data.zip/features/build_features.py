
import os
import pandas as pd
import numpy as np

PROC_DIR = os.path.join("data", "processed")

def load_best_source():
    merged_path = os.path.join(PROC_DIR, "merged.csv")
    clean_path = os.path.join(PROC_DIR, "ncrb_clean.csv")
    if os.path.exists(merged_path):
        return pd.read_csv(merged_path), True
    return pd.read_csv(clean_path), False

def add_per_capita(df):
    if "population" in df.columns:
        for col in ["cases_reported", "grand_total"]:
            if col in df.columns:
                df[f"{col}_per_100k"] = (df[col] / df["population"]) * 100000.0
    return df

def add_age_shares(df):
    # EDA-only shares; excluded from ML to avoid leakage
    child_cols = [c for c in df.columns if c.startswith("child_victims_of_rape") and c.endswith(("col_4","col_5","col_6","col_7"))]
    women_cols = [c for c in df.columns if c.startswith("women_victims_of_rape")]
    for group_cols, prefix in [(child_cols, "child"), (women_cols, "women")]:
        if group_cols:
            denom = df[group_cols].sum(axis=1).replace(0, np.nan)
            for c in group_cols:
                df[f"share_{prefix}_{c.split('_col_')[-1]}"] = df[c] / denom
    return df

def select_ml_features(df):
    y_col = "grand_total_per_100k" if "grand_total_per_100k" in df.columns else "grand_total"
    candidate_covars = [c for c in df.columns if c not in ("sl_no","state_ut","cases_reported","grand_total","cases_reported_per_100k","grand_total_per_100k")]
    leakage = ["child_victims_of_rape","women_victims_of_rape","total_girl","total_women","grand_total","cases_reported"]
    X_cols = [c for c in candidate_covars if not any(k in c for k in leakage)]
    if not X_cols:
        df["dummy_feature"] = 1.0
        X_cols = ["dummy_feature"]
    cols = ["state_ut", y_col] + X_cols
    ml = df[cols].copy().dropna(subset=[y_col])
    return ml, y_col, X_cols

def main():
    df, merged = load_best_source()
    df = add_per_capita(df)
    df = add_age_shares(df)
    ml, y_col, X_cols = select_ml_features(df)
    os.makedirs(PROC_DIR, exist_ok=True)
    out_path = os.path.join(PROC_DIR, "features.csv")
    ml.to_csv(out_path, index=False)
    print("Saved features to:", out_path)
    print("Target:", y_col)
    print("Features:", X_cols)

if __name__ == "__main__":
    main()
