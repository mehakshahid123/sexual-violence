
import os, pandas as pd
import matplotlib.pyplot as plt

PROC_DIR = os.path.join("data", "processed")
FIG_DIR = os.path.join("reports", "figures")

def main():
    df = pd.read_csv(os.path.join(PROC_DIR, "ncrb_clean.csv"))
    os.makedirs(FIG_DIR, exist_ok=True)

    if "grand_total" in df.columns:
        top = df.sort_values("grand_total", ascending=False).head(10)
        plt.figure()
        plt.barh(top["state_ut"], top["grand_total"])
        plt.gca().invert_yaxis()
        plt.xlabel("Grand Total (Count)")
        plt.title("Top 10 States/UTs by Reported Rape Victims (Grand Total)")
        plt.tight_layout()
        plt.savefig(os.path.join(FIG_DIR, "top10_grand_total.png"))
        plt.close()

    if "cases_reported" in df.columns and "grand_total" in df.columns:
        plt.figure()
        plt.scatter(df["cases_reported"], df["grand_total"])
        for _, row in df.iterrows():
            plt.annotate(row["state_ut"], (row["cases_reported"], row["grand_total"]), fontsize=6, alpha=0.6)
        plt.xlabel("Cases Reported")
        plt.ylabel("Grand Total (Victims)")
        plt.title("Cases Reported vs Grand Total")
        plt.tight_layout()
        plt.savefig(os.path.join(FIG_DIR, "cases_vs_grandtotal.png"))
        plt.close()

if __name__ == "__main__":
    main()
