
import os, joblib, numpy as np, pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score

PROC_DIR = os.path.join("data", "processed")
MODELS_DIR = "models"

def main():
    df = pd.read_csv(os.path.join(PROC_DIR, "features.csv"))
    y_source = "grand_total_per_100k" if "grand_total_per_100k" in df.columns else "grand_total"
    threshold = df[y_source].quantile(0.75)
    y = (df[y_source] >= threshold).astype(int)
    X_cols = [c for c in df.columns if c not in ("state_ut", y_source)]
    X = df[X_cols].values

    pipe = Pipeline([("scaler", StandardScaler(with_mean=False)),
                     ("clf", LogisticRegression(max_iter=500, class_weight="balanced"))])

    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    aucs, aps = [], []
    for tr, te in skf.split(X, y):
        pipe.fit(X[tr], y.iloc[tr])
        p = pipe.predict_proba(X[te])[:,1]
        aucs.append(roc_auc_score(y.iloc[te], p))
        aps.append(average_precision_score(y.iloc[te], p))
    print("ROC-AUC: %.3f ± %.3f" % (np.mean(aucs), np.std(aucs)))
    print("PR-AUC:  %.3f ± %.3f" % (np.mean(aps), np.std(aps)))

    pipe.fit(X, y)
    os.makedirs(MODELS_DIR, exist_ok=True)
    joblib.dump({"model": pipe, "features": X_cols, "target_source": y_source, "threshold": float(threshold)},
                os.path.join(MODELS_DIR, "clf_logreg.joblib"))
    print("Saved classifier.")

if __name__ == "__main__":
    main()
