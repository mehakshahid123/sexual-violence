
import os, joblib, numpy as np, pandas as pd
from sklearn.model_selection import KFold, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestRegressor

PROC_DIR = os.path.join("data", "processed")
MODELS_DIR = "models"

def main():
    df = pd.read_csv(os.path.join(PROC_DIR, "features.csv"))
    y_col = "grand_total_per_100k" if "grand_total_per_100k" in df.columns else "grand_total"
    X_cols = [c for c in df.columns if c not in ("state_ut", y_col)]
    X, y = df[X_cols].values, df[y_col].values

    pipe = Pipeline([("scaler", StandardScaler(with_mean=False)),
                     ("rf", RandomForestRegressor(n_estimators=300, random_state=42, min_samples_leaf=2, n_jobs=-1))])

    kf = KFold(n_splits=5, shuffle=True, random_state=42)
    mae = -cross_val_score(pipe, X, y, cv=kf, scoring="neg_mean_absolute_error")
    r2  =  cross_val_score(pipe, X, y, cv=kf, scoring="r2")
    print("MAE: %.2f ± %.2f" % (mae.mean(), mae.std()))
    print("R2:  %.3f ± %.3f" % (r2.mean(), r2.std()))

    pipe.fit(X, y)
    os.makedirs(MODELS_DIR, exist_ok=True)
    joblib.dump({"model": pipe, "features": X_cols, "target": y_col},
                os.path.join(MODELS_DIR, "reg_rf.joblib"))
    print("Saved regressor.")

if __name__ == "__main__":
    main()
