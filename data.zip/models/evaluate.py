
import os, joblib, pandas as pd
from sklearn.metrics import classification_report, roc_auc_score, average_precision_score, mean_absolute_error, r2_score

PROC_DIR = os.path.join("data", "processed")
MODELS_DIR = "models"

def main():
    df = pd.read_csv(os.path.join(PROC_DIR, "features.csv"))

    clf_path = os.path.join(MODELS_DIR, "clf_logreg.joblib")
    if os.path.exists(clf_path):
        bundle = joblib.load(clf_path)
        model, X_cols = bundle["model"], bundle["features"]
        y_source, thr = bundle["target_source"], bundle["threshold"]
        X = df[X_cols].values
        y = (df[y_source] >= thr).astype(int)
        proba = model.predict_proba(X)[:,1]
        preds = (proba >= 0.5).astype(int)
        print("=== Classification ===")
        print(classification_report(y, preds, digits=3))
        print("ROC-AUC:", roc_auc_score(y, proba))
        print("PR-AUC:", average_precision_score(y, proba))

    reg_path = os.path.join(MODELS_DIR, "reg_rf.joblib")
    if os.path.exists(reg_path):
        bundle = joblib.load(reg_path)
        model, X_cols, y_col = bundle["model"], bundle["features"], bundle["target"]
        X = df[X_cols].values
        y = df[y_col].values
        preds = model.predict(X)
        print("\n=== Regression ===")
        print("MAE:", float(mean_absolute_error(y, preds)))
        print("R2:", float(r2_score(y, preds)))

if __name__ == "__main__":
    main()
